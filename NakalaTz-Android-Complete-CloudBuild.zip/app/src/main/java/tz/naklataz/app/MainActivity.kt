package tz.naklataz.app

import android.os.Bundle
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private val endpoint = "https://kitambulisho.com/balance/"

    private lateinit var tokenInput: EditText
    private lateinit var typeSpinner: Spinner
    private lateinit var result: TextView
    private lateinit var checkButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 28f
        }

        val subtitle = TextView(this).apply {
            text = "Token / Balance Verification"
            textSize = 16f
        }

        tokenInput = EditText(this).apply {
            hint = "Ingiza token"
            inputType = InputType.TYPE_CLASS_TEXT
        }

        typeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                resources.getStringArray(R.array.token_types)
            )
        }

        checkButton = MaterialButton(this).apply {
            text = "VERIFY TOKEN"
        }

        result = TextView(this).apply {
            text = "Weka token kisha bonyeza VERIFY TOKEN."
            textSize = 16f
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(tokenInput)
        root.addView(typeSpinner)
        root.addView(checkButton)
        root.addView(result)

        setContentView(root)

        checkButton.setOnClickListener {
            val token = tokenInput.text.toString().trim()
            val type = typeSpinner.selectedItem.toString()

            if (token.isEmpty()) {
                result.text = "Tafadhali ingiza token."
                return@setOnClickListener
            }

            verifyToken(token, type)
        }
    }

    private fun verifyToken(token: String, type: String) {
        checkButton.isEnabled = false
        result.text = "Inathibitisha..."

        CoroutineScope(Dispatchers.IO).launch {
            val output = try {
                val json = JSONObject()
                    .put("token_value", token)
                    .put("token_type", type)

                val body = json.toString()
                    .toRequestBody("application/json".toMediaType())

                val request = Request.Builder()
                    .url(endpoint)
                    .post(body)
                    .addHeader("Accept", "application/json")
                    .build()

                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()

                    if (!response.isSuccessful) {
                        "API error: HTTP ${response.code}\n\n$text"
                    } else {
                        val parsed = JSONObject(text)
                        val success = parsed.optBoolean("success", false)
                        val message = parsed.optString("message", "")

                        if (success) {
                            buildString {
                                append("TOKEN VALID\n\n")
                                append("Message: $message\n")
                                append("Usages: ")
                                append(parsed.optString("code_usages", "-"))
                                append("\nUsages before: ")
                                append(parsed.optString("code_usages_before", "-"))
                                append("\nPrice: ")
                                append(parsed.optString("price_amount", "-"))
                                append("\nComment: ")
                                append(parsed.optString("comment", "-"))
                            }
                        } else {
                            "TOKEN INVALID\n\n$message"
                        }
                    }
                }
            } catch (e: Exception) {
                "Network/API error:\n${e.message ?: "Unknown error"}"
            }

            withContext(Dispatchers.Main) {
                result.text = output
                checkButton.isEnabled = true
            }
        }
    }
}
